ROSE DAILY TRACK — ANDROID APP PROJECT

This project wraps your supplied HTML order tracker in an Android WebView.
The HTML is bundled inside the app, so the tracker opens without internet.
Its orders and product presets use browser local storage on that phone.

BUILD AN APK (requires a PC and Android Studio):
1. Install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the extracted RoseDailyTrack folder.
4. Wait for Gradle sync to finish.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, click "locate". The APK is normally:
   app/build/outputs/apk/debug/app-debug.apk
7. Copy that APK to your Android phone and install it. If prompted, allow
   installation from that file manager/browser.

NOTES:
- The HTML source was kept as supplied.
- The app works offline for local order entry and local storage.
- Data is stored separately on each device; it does not automatically sync
  between phones or PCs.
- Fonts may fall back to system fonts while offline.
- This ZIP is the Android Studio project, not a compiled APK. A local Android
  SDK/Gradle build environment is required to produce the APK.
